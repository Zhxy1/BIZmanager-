export interface Purchase {
  id: string;
  date: string;
  amount: number;
  customer: string;
  customerEmail: string;
  item: string;
  method: 'stripe' | 'paypal' | 'cashapp' | 'manual';
}

export interface Roles {
  owner: string;
  coOwner: string;
  editors: string[];
  customers: string[];
}

export interface SiteSettings {
  masterPassword: string;
  isLocked: boolean;
}

export interface CalendarNote {
  date: string;
  note: string;
}

export interface AppData {
  purchases: Purchase[];
  roles: Roles;
  siteSettings: SiteSettings;
  calendar: Record<string, string>; // date string -> note
}
