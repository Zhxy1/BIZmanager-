import React, { useState, useEffect, useMemo } from 'react';
import { 
  Calendar as CalendarIcon, 
  DollarSign, 
  Users, 
  Settings, 
  Plus, 
  Trash2, 
  Download, 
  Upload,
  ChevronLeft,
  ChevronRight,
  CreditCard,
  ExternalLink,
  Save,
  LogIn,
  LogOut,
  AlertCircle,
  Lock,
  Unlock,
  Shield,
  User as UserIcon,
  Eye,
  EyeOff,
  Globe,
  CheckCircle2,
  HelpCircle,
  ShieldCheck,
  Info
} from 'lucide-react';
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  eachDayOfInterval, 
  isSameDay, 
  startOfYear,
  endOfYear,
  eachMonthOfInterval
} from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut,
  User
} from 'firebase/auth';
import { 
  collection, 
  doc, 
  onSnapshot, 
  setDoc, 
  addDoc, 
  deleteDoc, 
  query, 
  orderBy,
  getDocFromServer
} from 'firebase/firestore';
import { auth, db } from './firebase';
import { cn } from './lib/utils';
import { AppData, Purchase, Roles, SiteSettings } from './types';

// Error Handling Spec for Firestore Operations
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  // We don't throw here to avoid crashing the whole app, but we log it
}

const INITIAL_ROLES: Roles = {
  owner: 'louie4585.lewis@gmail.com',
  coOwner: '',
  editors: [],
  customers: []
};

const INITIAL_SITE_SETTINGS: SiteSettings = {
  masterPassword: 'admin',
  isLocked: true
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [data, setData] = useState<AppData>({ 
    purchases: [], 
    roles: INITIAL_ROLES, 
    siteSettings: INITIAL_SITE_SETTINGS,
    calendar: {} 
  });
  const [activeTab, setActiveTab] = useState<'dashboard' | 'calendar' | 'admin' | 'payments' | 'transfer' | 'settings' | 'domain' | 'help'>('dashboard');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [notification, setNotification] = useState<{ message: string, type: 'success' | 'error' | 'info' } | null>(null);

  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => setNotification(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Test Connection to Firestore
  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. ");
        }
      }
    }
    testConnection();
  }, []);

  // Firestore Listeners
  useEffect(() => {
    if (!isAuthReady || !user) {
      setLoading(false);
      return;
    }

    setLoading(true);

    // Listen to Roles
    const unsubscribeRoles = onSnapshot(doc(db, 'settings', 'roles'), (snapshot) => {
      if (snapshot.exists()) {
        setData(prev => ({ ...prev, roles: snapshot.data() as Roles }));
      } else {
        setDoc(doc(db, 'settings', 'roles'), INITIAL_ROLES).catch(e => handleFirestoreError(e, OperationType.WRITE, 'settings/roles'));
      }
    }, (e) => handleFirestoreError(e, OperationType.GET, 'settings/roles'));

    // Listen to Site Settings
    const unsubscribeSite = onSnapshot(doc(db, 'settings', 'site'), (snapshot) => {
      if (snapshot.exists()) {
        setData(prev => ({ ...prev, siteSettings: snapshot.data() as SiteSettings }));
      } else {
        setDoc(doc(db, 'settings', 'site'), INITIAL_SITE_SETTINGS).catch(e => handleFirestoreError(e, OperationType.WRITE, 'settings/site'));
      }
    }, (e) => handleFirestoreError(e, OperationType.GET, 'settings/site'));

    // Listen to Purchases
    const qPurchases = query(collection(db, 'purchases'), orderBy('date', 'desc'));
    const unsubscribePurchases = onSnapshot(qPurchases, (snapshot) => {
      const purchases = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Purchase));
      setData(prev => ({ ...prev, purchases }));
    }, (e) => handleFirestoreError(e, OperationType.LIST, 'purchases'));

    // Listen to Calendar
    const unsubscribeCalendar = onSnapshot(collection(db, 'calendar'), (snapshot) => {
      const calendar: Record<string, string> = {};
      snapshot.docs.forEach(d => {
        calendar[d.id] = d.data().note;
      });
      setData(prev => ({ ...prev, calendar }));
      setLoading(false);
    }, (e) => handleFirestoreError(e, OperationType.LIST, 'calendar'));

    return () => {
      unsubscribeRoles();
      unsubscribeSite();
      unsubscribePurchases();
      unsubscribeCalendar();
    };
  }, [isAuthReady, user]);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (e) {
      console.error("Login failed", e);
      setError("Login failed. Please try again.");
    }
  };

  const handleLogout = () => {
    signOut(auth);
    setIsUnlocked(false);
    setPasswordInput('');
  };

  const userRole = useMemo(() => {
    if (!user) return 'viewer';
    if (data.roles.owner === user.email) return 'owner';
    if (data.roles.coOwner === user.email) return 'co-owner';
    if (data.roles.editors.includes(user.email || '')) return 'editor';
    if (data.roles.customers?.includes(user.email || '')) return 'customer';
    // Default admin check from context
    if (user.email === "louie4585.lewis@gmail.com") return 'owner';
    return 'viewer';
  }, [data.roles, user]);

  const canEdit = ['owner', 'co-owner', 'editor'].includes(userRole);
  const isAdmin = ['owner', 'co-owner'].includes(userRole);
  const isCustomer = userRole === 'customer';

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === data.siteSettings.masterPassword) {
      setIsUnlocked(true);
      setError(null);
    } else {
      setError("Incorrect master password.");
    }
  };

  if (!isAuthReady) return <div className="flex items-center justify-center h-screen">Initializing...</div>;

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
        <div className="card max-w-md w-full text-center space-y-6 shadow-xl border-t-4 border-gray-900">
          <div className="w-16 h-16 bg-gray-900 text-white rounded-2xl flex items-center justify-center mx-auto shadow-lg">
            <Shield size={32} />
          </div>
          <div>
            <h1 className="text-2xl font-bold">BizManager Pro</h1>
            <p className="text-gray-500 mt-2">Professional Business Suite</p>
          </div>
          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded-md text-sm flex items-center gap-2 animate-shake">
              <AlertCircle size={16} /> {error}
            </div>
          )}
          <button onClick={handleLogin} className="btn btn-primary w-full justify-center py-3 text-lg">
            <LogIn size={20} /> Sign in with Google
          </button>

          <p className="text-[10px] text-gray-400 uppercase tracking-widest">Secure Infrastructure Powered by Google</p>
        </div>
      </div>
    );
  }

  if (!isUnlocked && data.siteSettings.isLocked) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative overflow-hidden">
        {/* Background Accents */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
          <div className="absolute -top-1/4 -left-1/4 w-1/2 h-1/2 bg-primary/5 rounded-full blur-[120px]"></div>
          <div className="absolute -bottom-1/4 -right-1/4 w-1/2 h-1/2 bg-primary/5 rounded-full blur-[120px]"></div>
        </div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="card max-w-md w-full text-center space-y-8 glass border-slate-800 shadow-2xl relative z-10"
        >
          <div className="w-20 h-20 bg-slate-900 border border-slate-800 text-primary rounded-3xl flex items-center justify-center mx-auto shadow-inner group">
            <Lock size={40} className="group-hover:scale-110 transition-transform duration-500" />
          </div>
          <div>
            <h1 className="text-3xl font-display font-black text-white tracking-tight">Vault Access</h1>
            <p className="text-slate-400 mt-2 text-sm">Authentication required for high-value asset management.</p>
          </div>
          <form onSubmit={handleUnlock} className="space-y-6">
            <div className="relative group">
              <input 
                type={showPassword ? "text" : "password"}
                className="input pr-12 py-4 bg-slate-900/50 border-slate-800 focus:border-primary text-center text-lg tracking-widest font-mono" 
                placeholder="••••••••"
                value={passwordInput}
                onChange={e => setPasswordInput(e.target.value)}
                autoFocus
              />
              <button 
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-primary transition-colors"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            {error && (
              <motion.div 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="text-red-400 text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2"
              >
                <AlertCircle size={14} /> Access Denied
              </motion.div>
            )}
            <button type="submit" className="btn btn-primary w-full justify-center py-4 text-sm uppercase font-black tracking-[0.2em]">
              <Unlock size={18} /> Initiate Unlock
            </button>
          </form>
          <div className="pt-4 flex flex-col gap-4">
            <button onClick={handleLogout} className="text-[10px] text-slate-500 hover:text-white uppercase tracking-widest font-bold transition-colors">
              Terminate Session: {user.email}
            </button>
            <div className="flex justify-center gap-2">
              <div className="w-1 h-1 rounded-full bg-slate-800"></div>
              <div className="w-1 h-1 rounded-full bg-slate-800"></div>
              <div className="w-1 h-1 rounded-full bg-slate-800"></div>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 flex font-sans selection:bg-primary/30 selection:text-primary">
      {/* Sidebar */}
      <aside className="w-72 glass border-r border-slate-800 flex flex-col h-screen sticky top-0 z-50">
        <div className="p-8">
          <div className="flex items-center gap-4 mb-12 group cursor-pointer">
            <div className="w-12 h-12 bg-primary text-black rounded-2xl flex items-center justify-center shadow-lg shadow-primary/20 group-hover:rotate-12 transition-transform duration-500">
              <Shield size={28} />
            </div>
            <div>
              <h1 className="text-2xl font-display font-black tracking-tighter text-white leading-none">BizManager</h1>
              <div className="text-[9px] text-primary font-black uppercase tracking-[0.4em] mt-1">Elite Edition</div>
            </div>
          </div>
          
          <nav className="space-y-2">
            {!isCustomer && (
              <>
                <SidebarItem 
                  active={activeTab === 'dashboard'} 
                  onClick={() => setActiveTab('dashboard')} 
                  icon={<DollarSign size={18} />} 
                  label="Executive Dashboard" 
                />
                <SidebarItem 
                  active={activeTab === 'calendar'} 
                  onClick={() => setActiveTab('calendar')} 
                  icon={<CalendarIcon size={18} />} 
                  label="Strategic Calendar" 
                />
                <SidebarItem 
                  active={activeTab === 'admin'} 
                  onClick={() => setActiveTab('admin')} 
                  icon={<Users size={18} />} 
                  label="Client Relations" 
                />
                <SidebarItem 
                  active={activeTab === 'payments'} 
                  onClick={() => setActiveTab('payments')} 
                  icon={<CreditCard size={18} />} 
                  label="Capital Flows" 
                />
                <SidebarItem 
                  active={activeTab === 'transfer'} 
                  onClick={() => setActiveTab('transfer')} 
                  icon={<Download size={18} />} 
                  label="Vault Migration" 
                />
              </>
            )}
            {isCustomer && (
              <SidebarItem 
                active={activeTab === 'dashboard'} 
                onClick={() => setActiveTab('dashboard')} 
                icon={<DollarSign size={18} />} 
                label="Investment Ledger" 
              />
            )}
            {isAdmin && (
              <>
                <div className="pt-6 pb-2 px-4 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">System Controls</div>
                <SidebarItem 
                  active={activeTab === 'settings'} 
                  onClick={() => setActiveTab('settings')} 
                  icon={<Settings size={18} />} 
                  label="Security Config" 
                />
                <SidebarItem 
                  active={activeTab === 'domain'} 
                  onClick={() => setActiveTab('domain')} 
                  icon={<Globe size={18} />} 
                  label="Brand Identity" 
                />
              </>
            )}
            <div className="pt-6 pb-2 px-4 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Support</div>
            <SidebarItem 
              active={activeTab === 'help'} 
              onClick={() => setActiveTab('help')} 
              icon={<HelpCircle size={18} />} 
              label="Concierge" 
            />
          </nav>
        </div>

        <div className="mt-auto p-8 border-t border-slate-800/50 bg-slate-900/40 backdrop-blur-md">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 rounded-2xl bg-slate-800 overflow-hidden border border-slate-700 shadow-inner group">
              {user.photoURL ? (
                <img src={user.photoURL} alt="User" referrerPolicy="no-referrer" className="group-hover:scale-110 transition-transform duration-500" />
              ) : (
                <UserIcon size={24} className="m-3 text-slate-500" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-black text-white truncate leading-tight">{user.displayName || 'Executive'}</p>
              <p className="text-[10px] text-primary font-mono uppercase tracking-tighter mt-0.5">{userRole}</p>
            </div>
          </div>
          <button 
            onClick={handleLogout} 
            className="btn btn-secondary w-full justify-center text-[10px] py-3 uppercase tracking-[0.2em] font-black border-slate-700 hover:bg-slate-800 hover:border-slate-600 group"
          >
            <LogOut size={14} className="group-hover:-translate-x-1 transition-transform" /> Terminate Session
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto p-12 bg-slate-950">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.3 }}
          >
            {notification && (
              <div className={cn(
                "fixed bottom-8 right-8 z-[100] p-5 rounded-2xl shadow-2xl border flex items-center gap-4 animate-in fade-in slide-in-from-bottom-8 duration-500 glass",
                notification.type === 'success' ? "border-green-500/20 text-green-400" : 
                notification.type === 'error' ? "border-red-500/20 text-red-400" : 
                "border-primary/20 text-primary"
              )}>
                {notification.type === 'success' ? <CheckCircle2 size={20} /> : 
                 notification.type === 'error' ? <AlertCircle size={20} /> : 
                 <Info size={20} />}
                <span className="text-sm font-bold tracking-tight">{notification.message}</span>
                <button onClick={() => setNotification(null)} className="ml-4 p-1 hover:bg-white/10 rounded-full transition-colors">
                  <Trash2 size={14} />
                </button>
              </div>
            )}
            {loading && <div className="fixed top-8 right-8 glass border border-primary/20 rounded-full px-6 py-2 text-[10px] font-black text-primary uppercase tracking-[0.2em] animate-pulse z-50">Synchronizing Ledger...</div>}
            {activeTab === 'dashboard' && <Dashboard data={data} canEdit={canEdit} isCustomer={isCustomer} userEmail={user.email || ''} setNotification={setNotification} />}
            {activeTab === 'calendar' && !isCustomer && <CalendarSection data={data} canEdit={canEdit} />}
            {activeTab === 'admin' && !isCustomer && <AdminPanel data={data} isAdmin={isAdmin} />}
            {activeTab === 'payments' && !isCustomer && <PaymentSettings />}
            {activeTab === 'transfer' && !isCustomer && <TransferSection data={data} setNotification={setNotification} />}
            {activeTab === 'settings' && isAdmin && <SettingsPanel data={data} setNotification={setNotification} />}
            {activeTab === 'domain' && isAdmin && <DomainSection />}
            {activeTab === 'help' && <HelpSection />}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}

function SidebarItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick} 
      className={cn(
        "w-full flex items-center gap-4 px-4 py-3 rounded-xl text-sm font-bold transition-all duration-300 group",
        active 
          ? "bg-primary text-black shadow-lg shadow-primary/20" 
          : "text-slate-400 hover:text-white hover:bg-slate-800/50"
      )}
    >
      <span className={cn("transition-transform duration-300 group-hover:scale-110", active ? "text-black" : "text-slate-500 group-hover:text-primary")}>
        {icon}
      </span>
      <span className="tracking-tight">{label}</span>
      {active && (
        <motion.div 
          layoutId="activeTab"
          className="ml-auto w-1.5 h-1.5 rounded-full bg-black"
        />
      )}
    </button>
  );
}

// --- Dashboard Section ---
function Dashboard({ data, canEdit, isCustomer, userEmail, setNotification }: { data: AppData, canEdit: boolean, isCustomer: boolean, userEmail: string, setNotification: (n: { type: 'success' | 'error' | 'info', message: string } | null) => void }) {
  const [newPurchase, setNewPurchase] = useState({ customer: '', item: '', amount: '', method: 'manual' as const, customerEmail: '' });

  const filteredPurchases = useMemo(() => {
    if (isCustomer) {
      return data.purchases.filter(p => p.customerEmail === userEmail);
    }
    return data.purchases;
  }, [data.purchases, isCustomer, userEmail]);

  const totalRevenue = filteredPurchases.reduce((sum, p) => sum + p.amount, 0);
  
  const chartData = useMemo(() => {
    const last7Days = Array.from({ length: 7 }).map((_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      const dateStr = format(d, 'yyyy-MM-dd');
      const dayTotal = filteredPurchases
        .filter(p => p.date.startsWith(dateStr))
        .reduce((sum, p) => sum + p.amount, 0);
      return { name: format(d, 'MMM dd'), amount: dayTotal };
    });
    return last7Days;
  }, [filteredPurchases]);

  const handleAddPurchase = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPurchase.customer || !newPurchase.amount) return;
    
    const purchase: Omit<Purchase, 'id'> = {
      date: new Date().toISOString(),
      customer: newPurchase.customer,
      item: newPurchase.item,
      amount: parseFloat(newPurchase.amount),
      method: newPurchase.method,
      customerEmail: newPurchase.customerEmail
    };

    try {
      await addDoc(collection(db, 'purchases'), purchase);
      setNewPurchase({ customer: '', item: '', amount: '', method: 'manual', customerEmail: '' });
      setNotification({ message: 'Transaction recorded successfully', type: 'success' });
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'purchases');
    }
  };

  const deletePurchase = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'purchases', id));
      setNotification({ message: 'Record removed from ledger', type: 'info' });
    } catch (e) {
      handleFirestoreError(e, OperationType.DELETE, `purchases/${id}`);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-10"
    >
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div>
          <h2 className="text-4xl font-display font-black tracking-tight text-white">
            {isCustomer ? 'Investment Ledger' : 'Executive Dashboard'}
          </h2>
          <p className="text-slate-400 mt-2 text-lg">
            {isCustomer ? 'Review your high-value transaction history' : 'Strategic overview of your business performance'}
          </p>
        </div>
        <div className="text-right bg-slate-900/50 p-6 rounded-2xl border border-slate-800 backdrop-blur-sm">
          <div className="text-xs text-slate-500 uppercase font-black tracking-[0.2em] mb-1">
            {isCustomer ? 'Total Capital Deployed' : 'Total Gross Revenue'}
          </div>
          <div className="text-5xl font-black text-primary font-mono">
            ${totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {!isCustomer && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="card h-96 flex flex-col">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-bold text-slate-300 uppercase tracking-widest text-xs">Revenue Analytics (7D)</h3>
                  <div className="w-2 h-2 rounded-full bg-primary animate-pulse"></div>
                </div>
                <div className="flex-1">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                      <XAxis 
                        dataKey="name" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#64748b', fontSize: 10 }} 
                      />
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#64748b', fontSize: 10 }} 
                        tickFormatter={(val) => `$${val}`}
                      />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '8px' }}
                        itemStyle={{ color: '#fbbf24' }}
                      />
                      <Bar dataKey="amount" fill="#fbbf24" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="card bg-slate-900 text-white flex flex-col justify-center relative overflow-hidden">
                <div className="absolute -right-10 -top-10 w-40 h-40 bg-primary/10 rounded-full blur-3xl"></div>
                <div className="relative z-10">
                  <div className="flex items-center gap-5 mb-8">
                    <div className="p-4 bg-primary/10 text-primary rounded-2xl border border-primary/20">
                      <ShieldCheck size={36} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-display font-bold">Vault Status</h3>
                      <p className="text-xs text-slate-400 uppercase tracking-widest">Enterprise Protection Active</p>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 rounded-xl bg-slate-800/50 border border-slate-700/50">
                      <span className="text-[10px] text-slate-500 uppercase font-bold tracking-tighter">Encryption Standard</span>
                      <span className="text-primary font-mono text-xs">AES-256 BIT</span>
                    </div>
                    <div className="flex justify-between items-center p-3 rounded-xl bg-slate-800/50 border border-slate-700/50">
                      <span className="text-[10px] text-slate-500 uppercase font-bold tracking-tighter">Access Protocol</span>
                      <span className="text-primary font-mono text-xs">RBAC MULTI-LAYER</span>
                    </div>
                    <div className="flex justify-between items-center p-3 rounded-xl bg-slate-800/50 border border-slate-700/50">
                      <span className="text-[10px] text-slate-500 uppercase font-bold tracking-tighter">Data Integrity</span>
                      <span className="text-primary font-mono text-xs">VERIFIED HASH</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="card">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-xl font-display font-bold">{isCustomer ? 'Transaction Ledger' : 'Recent Capital Flows'}</h3>
              <div className="flex gap-2">
                <div className="px-3 py-1 rounded-full bg-slate-800 text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Live Feed</div>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-800">
                    <th className="pb-4 font-bold text-slate-500 uppercase text-[10px] tracking-widest">Timestamp</th>
                    {!isCustomer && <th className="pb-4 font-bold text-slate-500 uppercase text-[10px] tracking-widest">Client Identity</th>}
                    <th className="pb-4 font-bold text-slate-500 uppercase text-[10px] tracking-widest">Asset/Service</th>
                    <th className="pb-4 font-bold text-slate-500 uppercase text-[10px] tracking-widest">Value</th>
                    <th className="pb-4 font-bold text-slate-500 uppercase text-[10px] tracking-widest">Status</th>
                    {canEdit && <th className="pb-4 text-right"></th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/50">
                  {filteredPurchases.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-12 text-center text-slate-500 italic font-mono text-xs">NO RECORDS FOUND IN CURRENT LEDGER</td>
                    </tr>
                  ) : (
                    filteredPurchases.map(p => (
                      <tr key={p.id} className="group hover:bg-slate-800/30 transition-colors">
                        <td className="py-4 text-slate-400 font-mono text-xs">{format(new Date(p.date), 'MMM dd, HH:mm:ss')}</td>
                        {!isCustomer && (
                          <td className="py-4">
                            <div className="font-bold text-slate-200">{p.customer}</div>
                            <div className="text-[10px] text-slate-500 font-mono">{p.customerEmail}</div>
                          </td>
                        )}
                        <td className="py-4 text-slate-300">{p.item}</td>
                        <td className="py-4 font-black text-primary">${p.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                        <td className="py-4">
                          <span className="px-2 py-1 rounded border border-primary/20 bg-primary/5 text-primary text-[9px] font-black uppercase tracking-tighter">
                            {p.method}
                          </span>
                        </td>
                        {canEdit && (
                          <td className="py-4 text-right">
                            <button 
                              onClick={() => deletePurchase(p.id)} 
                              className="p-2 text-slate-600 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                            >
                              <Trash2 size={14} />
                            </button>
                          </td>
                        )}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          {canEdit && (
            <div className="card">
              <h3 className="font-bold mb-4">Manual Entry</h3>
              <form onSubmit={handleAddPurchase} className="space-y-4">
                <div>
                  <label className="text-[10px] font-bold uppercase text-gray-400 block mb-1">Customer Name</label>
                  <input 
                    className="input" 
                    placeholder="e.g. John Doe"
                    value={newPurchase.customer}
                    onChange={e => setNewPurchase({...newPurchase, customer: e.target.value})}
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold uppercase text-gray-400 block mb-1">Customer Email (for access)</label>
                  <input 
                    className="input" 
                    placeholder="customer@example.com"
                    value={newPurchase.customerEmail}
                    onChange={e => setNewPurchase({...newPurchase, customerEmail: e.target.value})}
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold uppercase text-gray-400 block mb-1">Item / Service</label>
                  <input 
                    className="input" 
                    placeholder="e.g. Consulting"
                    value={newPurchase.item}
                    onChange={e => setNewPurchase({...newPurchase, item: e.target.value})}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold uppercase text-gray-400 block mb-1">Amount ($)</label>
                    <input 
                      type="number" 
                      className="input" 
                      placeholder="0.00"
                      value={newPurchase.amount}
                      onChange={e => setNewPurchase({...newPurchase, amount: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold uppercase text-gray-400 block mb-1">Method</label>
                    <select 
                      className="input"
                      value={newPurchase.method}
                      onChange={e => setNewPurchase({...newPurchase, method: e.target.value as any})}
                    >
                      <option value="manual">Manual</option>
                      <option value="stripe">Stripe</option>
                      <option value="paypal">PayPal</option>
                      <option value="cashapp">CashApp</option>
                    </select>
                  </div>
                </div>
                <button type="submit" className="btn btn-primary w-full justify-center mt-2">
                  <Plus size={18} /> Add Purchase
                </button>
              </form>
            </div>
          )}

          <div className="card bg-gray-900 text-white">
            <h3 className="font-bold mb-2">Quick Stats</h3>
            <div className="space-y-4 mt-4">
              <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                <span className="text-gray-400 text-sm">Total Records</span>
                <span className="font-bold">{filteredPurchases.length}</span>
              </div>
              {!isCustomer && (
                <div className="flex justify-between items-center border-b border-gray-800 pb-2">
                  <span className="text-gray-400 text-sm">Avg. Ticket</span>
                  <span className="font-bold">
                    ${filteredPurchases.length ? (totalRevenue / filteredPurchases.length).toFixed(2) : '0.00'}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// --- Calendar Section ---
function CalendarSection({ data, canEdit }: { data: AppData, canEdit: boolean }) {
  const [viewYear, setViewYear] = useState(new Date().getFullYear());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [note, setNote] = useState('');

  const years = [viewYear, viewYear + 1];

  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
    setNote(data.calendar[format(date, 'yyyy-MM-dd')] || '');
  };

  const handleSaveNote = async () => {
    if (!selectedDate) return;
    const dateStr = format(selectedDate, 'yyyy-MM-dd');
    
    try {
      if (note.trim()) {
        await setDoc(doc(db, 'calendar', dateStr), { date: dateStr, note });
      } else {
        await deleteDoc(doc(db, 'calendar', dateStr));
      }
      setSelectedDate(null);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `calendar/${dateStr}`);
    }
  };

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">2-Year Calendar</h2>
          <p className="text-gray-500">Plan your business schedule for {viewYear} - {viewYear + 1}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setViewYear(v => v - 1)} className="btn btn-secondary"><ChevronLeft size={18} /></button>
          <button onClick={() => setViewYear(v => v + 1)} className="btn btn-secondary"><ChevronRight size={18} /></button>
        </div>
      </header>

      <div className="space-y-12">
        {years.map(year => (
          <div key={year} className="space-y-6">
            <h3 className="text-2xl font-black border-b-4 border-gray-900 inline-block pb-1">{year}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {eachMonthOfInterval({
                start: startOfYear(new Date(year, 0, 1)),
                end: endOfYear(new Date(year, 0, 1))
              }).map(month => (
                <div key={month.toString()} className="card p-4">
                  <h4 className="font-bold mb-3 text-center uppercase tracking-widest text-sm border-b border-gray-100 pb-2">
                    {format(month, 'MMMM')}
                  </h4>
                  <div className="grid grid-cols-7 gap-1 text-[10px] text-center font-bold text-gray-400 mb-2">
                    <span>S</span><span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span>
                  </div>
                  <div className="grid grid-cols-7 gap-1">
                    {eachDayOfInterval({
                      start: startOfMonth(month),
                      end: endOfMonth(month)
                    }).map((day, i) => {
                      const dateStr = format(day, 'yyyy-MM-dd');
                      const hasNote = !!data.calendar[dateStr];
                      const isToday = isSameDay(day, new Date());
                      
                      const firstDayStyle = i === 0 ? { gridColumnStart: day.getDay() + 1 } : {};

                      return (
                        <button
                          key={day.toString()}
                          style={firstDayStyle}
                          onClick={() => handleDateClick(day)}
                          className={cn(
                            "aspect-square flex items-center justify-center rounded text-[10px] transition-all relative",
                            hasNote ? "bg-gray-900 text-white font-bold" : "hover:bg-gray-100",
                            isToday && !hasNote && "border-2 border-accent text-accent font-bold"
                          )}
                        >
                          {format(day, 'd')}
                          {hasNote && <div className="absolute top-0 right-0 w-1 h-1 bg-accent rounded-full m-0.5" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {selectedDate && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-xl font-bold mb-2">{format(selectedDate, 'MMMM dd, yyyy')}</h3>
            <p className="text-sm text-gray-500 mb-4">Add a note or event for this day.</p>
            <textarea
              className="input h-32 resize-none mb-4"
              placeholder="Enter details..."
              value={note}
              onChange={e => setNote(e.target.value)}
              disabled={!canEdit}
            />
            <div className="flex justify-end gap-3">
              <button onClick={() => setSelectedDate(null)} className="btn btn-secondary">Cancel</button>
              {canEdit && (
                <button onClick={handleSaveNote} className="btn btn-primary">
                  <Save size={18} /> Save Note
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// --- Admin Panel ---
function AdminPanel({ data, isAdmin }: { data: AppData, isAdmin: boolean }) {
  const [newEditor, setNewEditor] = useState('');
  const [newCustomer, setNewCustomer] = useState('');

  const updateRoles = async (newRoles: Roles) => {
    try {
      await setDoc(doc(db, 'settings', 'roles'), newRoles);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'settings/roles');
    }
  };

  const addEditor = () => {
    if (!newEditor || data.roles.editors.length >= 15) return;
    updateRoles({ ...data.roles, editors: [...data.roles.editors, newEditor] });
    setNewEditor('');
  };

  const removeEditor = (email: string) => {
    updateRoles({ ...data.roles, editors: data.roles.editors.filter(e => e !== email) });
  };

  const addCustomer = () => {
    if (!newCustomer) return;
    updateRoles({ ...data.roles, customers: [...(data.roles.customers || []), newCustomer] });
    setNewCustomer('');
  };

  const removeCustomer = (email: string) => {
    updateRoles({ ...data.roles, customers: data.roles.customers.filter(e => e !== email) });
  };

  return (
    <div className="space-y-8">
      <header>
        <h2 className="text-3xl font-bold">Team & Roles</h2>
        <p className="text-gray-500">Manage access permissions for your business</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-8">
          <div className="card">
            <h3 className="font-bold mb-4">Primary Roles</h3>
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-bold uppercase text-gray-400 block mb-1">Owner</label>
                <div className="flex gap-2">
                  <input 
                    className="input bg-gray-50" 
                    value={data.roles.owner} 
                    onChange={e => isAdmin && updateRoles({...data.roles, owner: e.target.value})}
                    disabled={!isAdmin}
                  />
                  <div className="px-3 py-2 bg-gray-900 text-white rounded text-xs flex items-center">OWNER</div>
                </div>
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase text-gray-400 block mb-1">Co-Owner</label>
                <div className="flex gap-2">
                  <input 
                    className="input" 
                    placeholder="Email address"
                    value={data.roles.coOwner} 
                    onChange={e => isAdmin && updateRoles({...data.roles, coOwner: e.target.value})}
                    disabled={!isAdmin}
                  />
                  <div className="px-3 py-2 bg-gray-200 text-gray-600 rounded text-xs flex items-center uppercase">CO-OWNER</div>
                </div>
              </div>
            </div>
          </div>

          <div className="card">
            <h3 className="font-bold mb-4">Editors ({data.roles.editors.length}/15)</h3>
            {isAdmin && (
              <div className="flex gap-2 mb-4">
                <input 
                  className="input" 
                  placeholder="Editor email"
                  value={newEditor}
                  onChange={e => setNewEditor(e.target.value)}
                />
                <button onClick={addEditor} className="btn btn-primary" disabled={data.roles.editors.length >= 15}>
                  <Plus size={18} />
                </button>
              </div>
            )}
            <div className="space-y-2">
              {data.roles.editors.map(email => (
                <div key={email} className="flex justify-between items-center p-2 bg-gray-50 rounded border border-gray-100">
                  <span className="text-sm font-medium">{email}</span>
                  {isAdmin && (
                    <button onClick={() => removeEditor(email)} className="text-gray-400 hover:text-red-500">
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
              ))}
              {data.roles.editors.length === 0 && (
                <div className="text-center py-4 text-gray-400 text-sm italic">No editors added</div>
              )}
            </div>
          </div>

          <div className="card bg-gray-900 text-white">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <ShieldCheck size={20} className="text-green-400" /> Security Audit Log
            </h3>
            <div className="space-y-3 text-[10px] font-mono text-gray-400">
              <div className="flex justify-between border-b border-gray-800 pb-2">
                <span>[SYSTEM] RBAC INITIALIZED</span>
                <span className="text-green-500">SUCCESS</span>
              </div>
              <div className="flex justify-between border-b border-gray-800 pb-2">
                <span>[FIRESTORE] RULES DEPLOYED</span>
                <span className="text-green-500">ACTIVE</span>
              </div>
              <div className="flex justify-between border-b border-gray-800 pb-2">
                <span>[AUTH] GOOGLE OAUTH 2.0</span>
                <span className="text-green-500">SECURE</span>
              </div>
              <div className="flex justify-between border-b border-gray-800 pb-2">
                <span>[ENCRYPTION] AES-256 AT REST</span>
                <span className="text-green-500">VERIFIED</span>
              </div>
              <div className="flex justify-center pt-4">
                <div className="px-3 py-1 bg-green-500/10 text-green-400 rounded-full border border-green-500/20 animate-pulse">
                  REAL-TIME MONITORING ACTIVE
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="card">
            <h3 className="font-bold mb-4">Customers</h3>
            {isAdmin && (
              <div className="flex gap-2 mb-4">
                <input 
                  className="input" 
                  placeholder="Customer email"
                  value={newCustomer}
                  onChange={e => setNewCustomer(e.target.value)}
                />
                <button onClick={addCustomer} className="btn btn-primary">
                  <Plus size={18} />
                </button>
              </div>
            )}
            <div className="space-y-2">
              {(data.roles.customers || []).map(email => (
                <div key={email} className="flex justify-between items-center p-2 bg-gray-50 rounded border border-gray-100">
                  <span className="text-sm font-medium">{email}</span>
                  {isAdmin && (
                    <button onClick={() => removeCustomer(email)} className="text-gray-400 hover:text-red-500">
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
              ))}
              {(!data.roles.customers || data.roles.customers.length === 0) && (
                <div className="text-center py-4 text-gray-400 text-sm italic">No customers added</div>
              )}
            </div>
          </div>

          <div className="card bg-gray-50 border-dashed">
            <h3 className="font-bold mb-4">Permissions Guide</h3>
            <div className="space-y-4 text-sm">
              <div className="p-3 bg-white rounded border border-gray-200">
                <div className="font-bold text-xs uppercase mb-1">Owner & Co-Owner</div>
                <p className="text-gray-500">Full access to all features, including role management and site transfer.</p>
              </div>
              <div className="p-3 bg-white rounded border border-gray-200">
                <div className="font-bold text-xs uppercase mb-1">Editors</div>
                <p className="text-gray-500">Can add/delete purchases and edit calendar notes. Cannot manage roles.</p>
              </div>
              <div className="p-3 bg-white rounded border border-gray-200">
                <div className="font-bold text-xs uppercase mb-1">Customers</div>
                <p className="text-gray-500">Can only see their own purchases. No access to calendar or admin tools.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// --- Settings Panel ---
function SettingsPanel({ data, setNotification }: { data: AppData, setNotification: (n: { message: string, type: 'success' | 'error' | 'info' }) => void }) {
  const [newPassword, setNewPassword] = useState(data.siteSettings.masterPassword);
  const [isLocked, setIsLocked] = useState(data.siteSettings.isLocked);
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      await setDoc(doc(db, 'settings', 'site'), {
        masterPassword: newPassword,
        isLocked: isLocked
      });
      setNotification({ message: 'Settings saved successfully!', type: 'success' });
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, 'settings/site');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-8">
      <header>
        <h2 className="text-3xl font-bold">Site Settings</h2>
        <p className="text-gray-500">Global configuration and security</p>
      </header>

      <div className="card max-w-2xl">
        <h3 className="font-bold mb-6 flex items-center gap-2">
          <Shield className="text-gray-400" size={20} /> Security Configuration
        </h3>
        <div className="space-y-6">
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-100">
            <div>
              <div className="font-bold text-sm">Master Password Lock</div>
              <p className="text-xs text-gray-500">Require a password to access the dashboard after login.</p>
            </div>
            <button 
              onClick={() => setIsLocked(!isLocked)}
              className={cn(
                "w-12 h-6 rounded-full transition-colors relative",
                isLocked ? "bg-gray-900" : "bg-gray-200"
              )}
            >
              <div className={cn(
                "absolute top-1 w-4 h-4 rounded-full bg-white transition-all",
                isLocked ? "left-7" : "left-1"
              )} />
            </button>
          </div>

          <div>
            <label className="text-[10px] font-bold uppercase text-gray-400 block mb-1">Master Password</label>
            <input 
              type="text" 
              className="input" 
              value={newPassword}
              onChange={e => setNewPassword(e.target.value)}
              placeholder="Enter new password"
            />
            <p className="text-[10px] text-gray-400 mt-1 italic">This password is shared between you and your team.</p>
          </div>

          <button 
            onClick={handleSave} 
            disabled={saving}
            className="btn btn-primary w-full justify-center"
          >
            {saving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      </div>
    </div>
  );
}

// --- Payment Settings ---
function PaymentSettings() {
  return (
    <div className="space-y-8">
      <header>
        <h2 className="text-3xl font-bold">Payment Systems</h2>
        <p className="text-gray-500">Link your payment providers to accept customer payments</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <PaymentCard 
          name="Stripe" 
          color="bg-[#635bff]" 
          description="Accept credit cards and digital wallets globally."
          link="https://dashboard.stripe.com/settings/payments"
        />
        <PaymentCard 
          name="PayPal" 
          color="bg-[#003087]" 
          description="The most recognized name in online payments."
          link="https://www.paypal.com/mep/dashboard"
        />
        <PaymentCard 
          name="Cash App" 
          color="bg-[#00d632]" 
          description="Fast and easy peer-to-peer payments for business."
          link="https://cash.app/help/us/en-us/3073-cash-for-business"
        />
      </div>

      <div className="card bg-blue-50 border-blue-100">
        <div className="flex gap-4">
          <div className="p-3 bg-blue-500 text-white rounded-full h-fit">
            <Settings size={24} />
          </div>
          <div>
            <h3 className="font-bold text-blue-900">Integration Note</h3>
            <p className="text-sm text-blue-700 mt-1">
              To fully automate purchase tracking, you'll need to set up Webhooks in your provider's dashboard 
              pointing to your application's API endpoints. Currently, all payments should be entered 
              manually in the Dashboard section.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function PaymentCard({ name, color, description, link }: { name: string, color: string, description: string, link: string }) {
  return (
    <div className="card flex flex-col h-full">
      <div className={cn("w-12 h-12 rounded-lg mb-4 flex items-center justify-center text-white font-black text-xl", color)}>
        {name[0]}
      </div>
      <h3 className="font-bold text-lg mb-2">{name}</h3>
      <p className="text-sm text-gray-500 mb-6 flex-1">{description}</p>
      <a 
        href={link} 
        target="_blank" 
        rel="noopener noreferrer"
        className="btn btn-secondary w-full justify-center"
      >
        Configure <ExternalLink size={14} />
      </a>
    </div>
  );
}

// --- Domain Section ---
function DomainSection() {
  const currentUrl = window.location.hostname;
  const isCustomDomain = !currentUrl.includes('run.app') && !currentUrl.includes('web.app') && !currentUrl.includes('localhost');

  return (
    <div className="space-y-8">
      <header>
        <h2 className="text-3xl font-bold">Domain & Custom Branding</h2>
        <p className="text-gray-500">Connect your professional .com or .net domain</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-8">
          <div className="card">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <Globe className="text-accent" size={20} /> Current Domain Status
            </h3>
            <div className="p-4 bg-gray-50 rounded-lg border border-gray-100 flex items-center justify-between">
              <div>
                <div className="text-sm font-mono text-gray-600">{currentUrl}</div>
                <div className="text-[10px] text-gray-400 mt-1 uppercase font-bold">
                  {isCustomDomain ? 'Custom Domain Active' : 'Default Applet URL'}
                </div>
              </div>
              {isCustomDomain ? (
                <div className="text-green-500 flex items-center gap-1 text-xs font-bold">
                  <CheckCircle2 size={16} /> VERIFIED
                </div>
              ) : (
                <div className="text-amber-500 flex items-center gap-1 text-xs font-bold">
                  <AlertCircle size={16} /> SUBDOMAIN
                </div>
              )}
            </div>
          </div>

          <div className="card">
            <h3 className="font-bold mb-4">Domain Registration & Pricing</h3>
            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-100">
                <div>
                  <div className="font-bold text-lg">.com Domain</div>
                  <div className="text-xs text-gray-500 italic">Professional standard</div>
                </div>
                <div className="text-2xl font-black text-gray-900">$65<span className="text-xs font-normal text-gray-400">/yr</span></div>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-100">
                <div>
                  <div className="font-bold text-lg">.net Domain</div>
                  <div className="text-xs text-gray-500 italic">Network & Infrastructure</div>
                </div>
                <div className="text-2xl font-black text-gray-900">$125<span className="text-xs font-normal text-gray-400">/yr</span></div>
              </div>
              <div className="p-4 bg-blue-50 border border-blue-100 rounded-lg">
                <h4 className="font-bold text-blue-900 text-xs uppercase mb-2">Registration Process</h4>
                <p className="text-blue-700 text-xs">
                  All domains registered through BizManager Pro are fully managed and secured with enterprise-grade DNS protection. Contact our support team to initiate your registration.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="card bg-gray-900 text-white">
          <h3 className="font-bold mb-4 flex items-center gap-2">
            <Shield size={20} /> Branding & Watermark
          </h3>
          <p className="text-sm text-gray-400 mb-6">
            To support the premium infrastructure and professional features, a small watermark is included in the sidebar.
          </p>
          <div className="p-6 border border-gray-800 rounded-lg bg-black/20 text-center">
            <div className="text-xs font-black text-gray-500 uppercase tracking-tighter flex items-center justify-center gap-2">
              <Shield size={14} /> BizManager Pro
            </div>
            <div className="text-[8px] text-gray-600 mt-1">SECURED BY ENTERPRISE ENCRYPTION</div>
          </div>
          <div className="mt-8 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded bg-gray-800 flex items-center justify-center">
                <CheckCircle2 size={16} className="text-green-500" />
              </div>
              <div className="text-xs">
                <div className="font-bold">Encrypted Data Streams</div>
                <div className="text-gray-500">AES-256 bit encryption for all business records.</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded bg-gray-800 flex items-center justify-center">
                <CheckCircle2 size={16} className="text-green-500" />
              </div>
              <div className="text-xs">
                <div className="font-bold">Role-Based Isolation</div>
                <div className="text-gray-500">Customers can never access team-only data.</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// --- Transfer Section ---
function TransferSection({ data, setNotification }: { data: AppData, setNotification: (n: { message: string, type: 'success' | 'error' | 'info' }) => void }) {
  const [importText, setImportText] = useState('');

  const exportData = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bizmanager-export-${format(new Date(), 'yyyy-MM-dd')}.json`;
    a.click();
  };

  const handleImport = async () => {
    try {
      const parsed = JSON.parse(importText);
      if (parsed.purchases && parsed.roles && parsed.calendar) {
        await setDoc(doc(db, 'settings', 'roles'), parsed.roles);
        if (parsed.siteSettings) {
          await setDoc(doc(db, 'settings', 'site'), parsed.siteSettings);
        }
        
        for (const p of parsed.purchases) {
          const { id, ...rest } = p;
          await setDoc(doc(db, 'purchases', id || Math.random().toString(36).substr(2, 9)), rest);
        }

        for (const [date, note] of Object.entries(parsed.calendar)) {
          await setDoc(doc(db, 'calendar', date), { date, note });
        }

        setImportText('');
        setNotification({ message: 'Data imported successfully!', type: 'success' });
      } else {
        setNotification({ message: 'Invalid data format.', type: 'error' });
      }
    } catch (e) {
      console.error(e);
      setNotification({ message: 'Failed to parse or import data.', type: 'error' });
    }
  };

  return (
    <div className="space-y-8">
      <header>
        <h2 className="text-3xl font-bold">Transfer Site Data</h2>
        <p className="text-gray-500">Export or import your entire business configuration</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="card">
          <h3 className="font-bold mb-2">Export Data</h3>
          <p className="text-sm text-gray-500 mb-6">Download a JSON file containing all your purchases, roles, and calendar notes.</p>
          <button onClick={exportData} className="btn btn-primary w-full justify-center">
            <Download size={18} /> Download Export File
          </button>
        </div>

        <div className="card">
          <h3 className="font-bold mb-2">Import Data</h3>
          <p className="text-sm text-gray-500 mb-4">Paste your exported JSON code below to restore or transfer your site.</p>
          <textarea 
            className="input h-32 font-mono text-[10px] mb-4" 
            placeholder='{"purchases": [...], "roles": {...}, "calendar": {...}}'
            value={importText}
            onChange={e => setImportText(e.target.value)}
          />
          <button onClick={handleImport} className="btn btn-secondary w-full justify-center">
            <Upload size={18} /> Import from Code
          </button>
        </div>
      </div>

      <div className="card bg-gray-900 text-white">
        <h3 className="font-bold mb-4">How to Transfer to Customer</h3>
        <ol className="list-decimal list-inside space-y-4 text-sm text-gray-300">
          <li>Complete the setup and enter all initial data for your customer.</li>
          <li>Go to the <span className="text-white font-bold">Export Data</span> section above and download the file.</li>
          <li>Provide the customer with the link to their new site instance.</li>
          <li>Instruct the customer to go to this <span className="text-white font-bold">Transfer</span> page and paste the code from the file into the <span className="text-white font-bold">Import</span> box.</li>
          <li>Once they click <span className="text-white font-bold">Import from Code</span>, their site will be fully populated with your setup.</li>
        </ol>
      </div>
    </div>
  );
}

function HelpSection() {
  return (
    <div className="space-y-8">
      <header>
        <h2 className="text-3xl font-bold">Help & Support</h2>
        <p className="text-gray-500">Frequently asked questions and system guidance</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="card">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <Lock className="text-accent" size={20} /> Security & Passwords
            </h3>
            <div className="space-y-4 text-sm">
              <div>
                <div className="font-bold">How do I change the master password?</div>
                <p className="text-gray-500 mt-1">Go to the <span className="font-bold">Settings</span> tab in the sidebar. Under "Security Configuration", you'll find the Master Password field. Enter your new password and click "Save Settings".</p>
              </div>
              <div>
                <div className="font-bold">What is the default password?</div>
                <p className="text-gray-500 mt-1">The initial system password is provided during setup. If you have already changed it, please use your custom master password to unlock the dashboard.</p>
              </div>
              <div>
                <div className="font-bold">Is my data encrypted?</div>
                <p className="text-gray-500 mt-1">Yes, all data is encrypted at rest using AES-256 bit encryption provided by Google Cloud Infrastructure. Access is strictly controlled via Role-Based Access Control (RBAC).</p>
              </div>
            </div>
          </div>

          <div className="card">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <Users className="text-accent" size={20} /> Roles & Permissions
            </h3>
            <div className="space-y-4 text-sm">
              <div>
                <div className="font-bold">What can Customers see?</div>
                <p className="text-gray-500 mt-1">Customers can only see the "My Purchases" tab. They are strictly isolated and cannot see any team data, calendar notes, or other customers' information.</p>
              </div>
              <div>
                <div className="font-bold">How many Editors can I have?</div>
                <p className="text-gray-500 mt-1">The system supports up to 15 editors. If you need more, please contact support for an enterprise upgrade.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="card">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <Globe className="text-accent" size={20} /> Domain & Branding
            </h3>
            <div className="space-y-4 text-sm text-gray-500">
              <p>Professional domains are available directly through BizManager Pro. A <span className="font-bold">.com</span> domain is <span className="font-bold">$65/year</span> and a <span className="font-bold">.net</span> domain is <span className="font-bold">$125/year</span>.</p>
              <p>Custom domains enhance your professional image and make it easier for customers to find your business. All registrations include managed DNS and security protection.</p>
            </div>
          </div>

          <div className="card bg-gray-900 text-white">
            <h3 className="font-bold mb-4">Need More Help?</h3>
            <p className="text-sm text-gray-400 mb-6">If you encounter any technical issues or have specific feature requests, our support team is available 24/7.</p>
            <button className="btn btn-primary w-full justify-center">
              Contact Support Team
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
